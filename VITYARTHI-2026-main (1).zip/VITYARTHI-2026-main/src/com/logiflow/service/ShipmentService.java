package com.logiflow.service;

import com.logiflow.exception.InvalidShipmentDataException;
import com.logiflow.exception.ShipmentNotFoundException;
import com.logiflow.model.Shipment;
import com.logiflow.model.ShipmentStatus;
import com.logiflow.pattern.Observer;
import com.logiflow.pattern.ShipmentFactory;
import com.logiflow.pattern.Subject;
import com.logiflow.storage.AuditLogger;
import com.logiflow.storage.FilePersistenceManager;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Service managing shipment lifecycle, observer dispatching, and persistent state.
 * Implements the Subject role in the Observer Design Pattern.
 */
public class ShipmentService implements Subject {

    private final Map<String, Shipment> shipments = new ConcurrentHashMap<>();
    private final List<Observer> observers = new ArrayList<>();

    public ShipmentService() {
        // Observers can be registered by callers
    }

    @Override
    public synchronized void registerObserver(Observer observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }

    @Override
    public synchronized void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    private synchronized void notifyStatusChanged(Shipment shipment, ShipmentStatus oldStatus, ShipmentStatus newStatus, String notes) {
        for (Observer obs : observers) {
            try {
                obs.onStatusUpdate(shipment, oldStatus, newStatus, notes);
            } catch (Exception e) {
                AuditLogger.getInstance().error("ShipmentService", "Observer notification error: " + e.getMessage());
            }
        }
    }

    public synchronized void notifyTelemetryAlert(String vehicleId, String message, boolean isWarning) {
        for (Observer obs : observers) {
            try {
                obs.onTelemetryAlert(vehicleId, message, isWarning);
            } catch (Exception e) {
                AuditLogger.getInstance().error("ShipmentService", "Telemetry alert error: " + e.getMessage());
            }
        }
    }

    public Shipment createShipment(String type, String id, String sender, String receiver,
                                   String origin, String destination, double weight,
                                   double volume, double declaredValue, double extraParam)
            throws InvalidShipmentDataException {

        if (shipments.containsKey(id)) {
            throw new InvalidShipmentDataException("id", "A shipment with tracking ID '" + id + "' already exists.");
        }

        Shipment shipment = ShipmentFactory.createShipment(
                type, id, sender, receiver, origin, destination, weight, volume, declaredValue, extraParam);

        shipments.put(shipment.getId(), shipment);
        AuditLogger.getInstance().info("ShipmentService", "Created new shipment: " + shipment);
        notifyStatusChanged(shipment, ShipmentStatus.CREATED, ShipmentStatus.CREATED, "Registered into intake system");
        return shipment;
    }

    public Shipment getShipment(String id) throws ShipmentNotFoundException {
        Shipment s = shipments.get(id);
        if (s == null) {
            throw new ShipmentNotFoundException(id);
        }
        return s;
    }

    public void updateStatus(String shipmentId, ShipmentStatus newStatus, String notes) throws ShipmentNotFoundException {
        Shipment shipment = getShipment(shipmentId);
        ShipmentStatus oldStatus = shipment.getStatus();
        shipment.setStatus(newStatus);
        AuditLogger.getInstance().info("ShipmentService",
                String.format("Status transition for %s: %s -> %s (%s)", shipmentId, oldStatus, newStatus, notes));
        notifyStatusChanged(shipment, oldStatus, newStatus, notes);
    }

    public List<Shipment> getAllShipments() {
        return new ArrayList<>(shipments.values());
    }

    public List<Shipment> getPendingShipments() {
        return shipments.values().stream()
                .filter(s -> s.getStatus() == ShipmentStatus.CREATED)
                .sorted() // sorted by natural order (PriorityQueue-like comparison)
                .collect(Collectors.toList());
    }

    public List<Shipment> getShipmentsByOrigin(String origin) {
        return shipments.values().stream()
                .filter(s -> s.getOriginCode().equalsIgnoreCase(origin))
                .collect(Collectors.toList());
    }

    public void saveToFile(String filePath) throws IOException {
        FilePersistenceManager.saveShipmentsToCsv(shipments.values(), filePath);
        AuditLogger.getInstance().info("Persistence", "Persisted " + shipments.size() + " shipments to " + filePath);
    }

    public void loadFromFile(String filePath) throws IOException {
        List<Shipment> loaded = FilePersistenceManager.loadShipmentsFromCsv(filePath);
        for (Shipment s : loaded) {
            shipments.put(s.getId(), s);
        }
        AuditLogger.getInstance().info("Persistence", "Loaded " + loaded.size() + " shipments from " + filePath);
    }
}
