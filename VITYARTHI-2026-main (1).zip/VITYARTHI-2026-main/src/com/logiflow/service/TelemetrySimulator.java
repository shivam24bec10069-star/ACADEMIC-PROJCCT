package com.logiflow.service;

import com.logiflow.exception.RouteNotFoundException;
import com.logiflow.exception.ShipmentNotFoundException;
import com.logiflow.model.*;
import com.logiflow.pattern.FastestRoutingStrategy;
import com.logiflow.service.RoutingService.PathResult;
import com.logiflow.storage.AuditLogger;

import java.util.*;
import java.util.concurrent.*;

/**
 * Multithreaded telemetry engine simulating real-time GPS tracking, sensor telemetry,
 * weather/traffic incidents, and shipment transit execution across asynchronous worker threads.
 */
public class TelemetrySimulator {

    private final RoutingService routingService;
    private final FleetService fleetService;
    private final ShipmentService shipmentService;
    private final ExecutorService executor;
    private final Random random = new Random(42); // deterministic seed for reproducibility

    public TelemetrySimulator(RoutingService routingService, FleetService fleetService, ShipmentService shipmentService) {
        this.routingService = routingService;
        this.fleetService = fleetService;
        this.shipmentService = shipmentService;
        this.executor = Executors.newFixedThreadPool(4, new ThreadFactory() {
            private int counter = 1;
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "Telemetry-Worker-" + (counter++));
                t.setDaemon(true);
                return t;
            }
        });
    }

    /**
     * Executes an accelerated real-time simulation of all assigned vehicles carrying freight.
     * Uses CountDownLatch to coordinate multiple concurrent vehicle delivery threads.
     */
    public void simulateActiveTransits(boolean synchronousWait, int simulatedStepDelayMs) {
        List<Vehicle> activeVehicles = new ArrayList<>();
        for (Vehicle v : fleetService.getAllVehicles()) {
            if (!v.getLoadedShipmentIds().isEmpty()) {
                activeVehicles.add(v);
            }
        }

        if (activeVehicles.isEmpty()) {
            System.out.println("[Telemetry] No active dispatched vehicles to simulate. Run dispatch first!");
            return;
        }

        CountDownLatch latch = new CountDownLatch(activeVehicles.size());

        System.out.printf("[Telemetry Engine] Initiating concurrent transit simulation for %d fleet units...%n",
                activeVehicles.size());

        for (Vehicle vehicle : activeVehicles) {
            executor.submit(() -> {
                try {
                    simulateVehicleMission(vehicle, simulatedStepDelayMs);
                } catch (Exception e) {
                    AuditLogger.getInstance().error("Telemetry", "Simulation error on " + vehicle.getId() + ": " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }

        if (synchronousWait) {
            try {
                latch.await();
                System.out.println("[Telemetry Engine] All fleet missions completed successfully.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("[Telemetry Engine] Simulation interrupted: " + e.getMessage());
            }
        }
    }

    private void simulateVehicleMission(Vehicle vehicle, int stepDelayMs) {
        List<String> shipmentIds = new ArrayList<>(vehicle.getLoadedShipmentIds());
        if (shipmentIds.isEmpty()) return;

        // Retrieve primary destination from first loaded shipment
        String originHub = vehicle.getCurrentLocationCode();
        String destinationHub = originHub;
        try {
            Shipment sample = shipmentService.getShipment(shipmentIds.get(0));
            destinationHub = sample.getDestinationCode();
        } catch (ShipmentNotFoundException e) {
            // fallback
        }

        PathResult pathResult;
        try {
            pathResult = routingService.findOptimalPath(originHub, destinationHub, new FastestRoutingStrategy());
        } catch (RouteNotFoundException e) {
            pathResult = null;
        }

        // Set shipments to IN_TRANSIT
        for (String id : shipmentIds) {
            try {
                shipmentService.updateStatus(id, ShipmentStatus.IN_TRANSIT,
                        "Departed " + originHub + " aboard " + vehicle.getId());
            } catch (ShipmentNotFoundException ignored) {}
        }

        List<RouteSegment> segments = (pathResult != null && !pathResult.getSegments().isEmpty())
                ? pathResult.getSegments()
                : Collections.singletonList(new RouteSegment(originHub, destinationHub, 500.0, 6.0, 10.0, 8.0));

        double accumulatedDistance = 0.0;
        String currentHub = originHub;

        for (RouteSegment segment : segments) {
            try {
                Thread.sleep(stepDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            accumulatedDistance += segment.getDistanceKm();
            currentHub = segment.getDestinationCode();
            vehicle.setCurrentLocationCode(currentHub);

            // Random incident check: 15% probability of traffic delay
            if (random.nextDouble() < 0.15) {
                shipmentService.notifyTelemetryAlert(vehicle.getId(),
                        "Traffic congestion / checkpoint delay at " + currentHub + ". ETA adjusted.", true);
                for (String id : shipmentIds) {
                    try {
                        shipmentService.updateStatus(id, ShipmentStatus.DELAYED, "Traffic delay near " + currentHub);
                    } catch (ShipmentNotFoundException ignored) {}
                }
                try {
                    Thread.sleep(stepDelayMs / 2);
                } catch (InterruptedException ignored) {}
            } else {
                shipmentService.notifyTelemetryAlert(vehicle.getId(),
                        String.format("Crossed checkpoint %s -> %s (Odometer: +%.1f km, Battery/Fuel: %.0f%%)",
                                segment.getSourceCode(), currentHub, segment.getDistanceKm(), vehicle.getFuelOrBatteryPercent()), false);
            }
        }

        // Complete delivery
        vehicle.completeMission(accumulatedDistance, currentHub);

        for (String id : shipmentIds) {
            try {
                shipmentService.updateStatus(id, ShipmentStatus.DELIVERED,
                        "Delivered at destination depot " + currentHub + " by driver " + vehicle.getDriverName());
            } catch (ShipmentNotFoundException ignored) {}
        }

        AuditLogger.getInstance().info("Telemetry",
                String.format("Mission completed for %s. Total trip: %.1f km at %s",
                        vehicle.getId(), accumulatedDistance, currentHub));
    }

    public void shutdown() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(3, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
    }
}
