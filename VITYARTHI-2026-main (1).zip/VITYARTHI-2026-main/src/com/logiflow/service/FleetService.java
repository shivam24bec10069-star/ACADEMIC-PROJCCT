package com.logiflow.service;

import com.logiflow.model.Vehicle;
import com.logiflow.model.VehicleType;
import com.logiflow.storage.AuditLogger;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Service managing corporate fleet transport units, assignments, and availability.
 */
public class FleetService {

    private final Map<String, Vehicle> fleet = new ConcurrentHashMap<>();

    public FleetService() {
        initializeDefaultFleet();
    }

    public void registerVehicle(Vehicle vehicle) {
        fleet.put(vehicle.getId(), vehicle);
        AuditLogger.getInstance().info("Fleet", "Registered vehicle " + vehicle.getId() + " (" + vehicle.getType() + ")");
    }

    public Optional<Vehicle> getVehicle(String id) {
        return Optional.ofNullable(fleet.get(id));
    }

    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(fleet.values());
    }

    public List<Vehicle> getAvailableVehicles() {
        return fleet.values().stream()
                .filter(Vehicle::isAvailable)
                .collect(Collectors.toList());
    }

    public List<Vehicle> getAvailableVehiclesAtHub(String hubCode) {
        return fleet.values().stream()
                .filter(v -> v.isAvailable() && v.getCurrentLocationCode().equalsIgnoreCase(hubCode))
                .collect(Collectors.toList());
    }

    public Optional<Vehicle> findBestVehicleForShipment(String originHub, double weightKg, double volumeM3) {
        return fleet.values().stream()
                .filter(Vehicle::isAvailable)
                .filter(v -> v.getCurrentLocationCode().equalsIgnoreCase(originHub))
                .filter(v -> v.canAccommodate(weightKg, volumeM3))
                // Prefer vehicle whose capacity closest matches weight without overkill
                .min(Comparator.comparingDouble(v -> v.getType().getMaxPayloadKg() - weightKg));
    }

    private void initializeDefaultFleet() {
        registerVehicle(new Vehicle("FLT-VN101", VehicleType.VAN, "Marcus Vance", "JFK"));
        registerVehicle(new Vehicle("FLT-VN102", VehicleType.VAN, "Elena Rostova", "ORD"));
        registerVehicle(new Vehicle("FLT-TK201", VehicleType.TRUCK, "David Chen", "JFK"));
        registerVehicle(new Vehicle("FLT-TK202", VehicleType.TRUCK, "Sarah Jenkins", "ORD"));
        registerVehicle(new Vehicle("FLT-TK203", VehicleType.TRUCK, "James Rodriguez", "ATL"));
        registerVehicle(new Vehicle("FLT-SM301", VehicleType.SEMI_TRAILER, "Robert Kowalski", "DFW"));
        registerVehicle(new Vehicle("FLT-SM302", VehicleType.SEMI_TRAILER, "Aisha Morales", "DEN"));
        registerVehicle(new Vehicle("FLT-EV401", VehicleType.ELECTRIC_CARGO, "Liam O'Connor", "SEA"));
        registerVehicle(new Vehicle("FLT-EV402", VehicleType.ELECTRIC_CARGO, "Maya Patel", "LAX"));
        registerVehicle(new Vehicle("FLT-TK204", VehicleType.TRUCK, "Kenji Sato", "MIA"));
    }
}
