package com.logiflow.service;

import com.logiflow.exception.InsufficientCapacityException;
import com.logiflow.exception.ShipmentNotFoundException;
import com.logiflow.model.Shipment;
import com.logiflow.model.ShipmentStatus;
import com.logiflow.model.Vehicle;
import com.logiflow.storage.AuditLogger;

import java.util.*;

/**
 * Service managing intelligent freight dispatching and resource allocation.
 * Uses PriorityQueue to ensure high-priority express freight is scheduled first.
 */
public class DispatchService {

    private final ShipmentService shipmentService;
    private final FleetService fleetService;
    private final PriorityQueue<Shipment> dispatchQueue;

    public DispatchService(ShipmentService shipmentService, FleetService fleetService) {
        this.shipmentService = shipmentService;
        this.fleetService = fleetService;
        this.dispatchQueue = new PriorityQueue<>(); // Uses Shipment's compareTo
    }

    /**
     * Enqueues pending shipments into the priority dispatch queue.
     */
    public synchronized void enqueuePendingShipments() {
        dispatchQueue.clear();
        List<Shipment> pending = shipmentService.getPendingShipments();
        dispatchQueue.addAll(pending);
        AuditLogger.getInstance().dispatch("DispatchService", "Enqueued " + dispatchQueue.size() + " pending shipments for allocation.");
    }

    public synchronized int getQueueSize() {
        return dispatchQueue.size();
    }

    /**
     * Attempts to automatically match and dispatch all queued shipments to appropriate fleet vehicles.
     * Returns a summary report of successful and failed allocations.
     */
    public synchronized DispatchReport dispatchAll() {
        enqueuePendingShipments();

        List<DispatchRecord> successful = new ArrayList<>();
        List<DispatchRecord> unassigned = new ArrayList<>();

        while (!dispatchQueue.isEmpty()) {
            Shipment shipment = dispatchQueue.poll();
            String origin = shipment.getOriginCode();

            Optional<Vehicle> candidateVehicle = fleetService.findBestVehicleForShipment(
                    origin, shipment.getWeightKg(), shipment.getVolumeM3());

            if (candidateVehicle.isPresent()) {
                Vehicle vehicle = candidateVehicle.get();
                try {
                    vehicle.loadShipment(shipment);
                    shipmentService.updateStatus(shipment.getId(), ShipmentStatus.ASSIGNED,
                            "Loaded on " + vehicle.getId() + " (" + vehicle.getDriverName() + ")");

                    successful.add(new DispatchRecord(shipment, vehicle, "Assigned successfully"));
                    AuditLogger.getInstance().dispatch("DispatchService",
                            String.format("Assigned shipment %s (%.1f kg) -> Vehicle %s at %s",
                                    shipment.getId(), shipment.getWeightKg(), vehicle.getId(), origin));
                } catch (InsufficientCapacityException | ShipmentNotFoundException e) {
                    unassigned.add(new DispatchRecord(shipment, null, e.getMessage()));
                }
            } else {
                unassigned.add(new DispatchRecord(shipment, null,
                        "No available fleet vehicle with adequate capacity at hub " + origin));
                AuditLogger.getInstance().warn("DispatchService",
                        "Failed allocation for shipment " + shipment.getId() + ": No capacity at " + origin);
            }
        }

        return new DispatchReport(successful, unassigned);
    }

    public static class DispatchRecord {
        private final Shipment shipment;
        private final Vehicle vehicle;
        private final String message;

        public DispatchRecord(Shipment shipment, Vehicle vehicle, String message) {
            this.shipment = shipment;
            this.vehicle = vehicle;
            this.message = message;
        }

        public Shipment getShipment() { return shipment; }
        public Vehicle getVehicle() { return vehicle; }
        public String getMessage() { return message; }
    }

    public static class DispatchReport {
        private final List<DispatchRecord> successful;
        private final List<DispatchRecord> failed;

        public DispatchReport(List<DispatchRecord> successful, List<DispatchRecord> failed) {
            this.successful = successful;
            this.failed = failed;
        }

        public List<DispatchRecord> getSuccessful() { return successful; }
        public List<DispatchRecord> getFailed() { return failed; }

        public String printSummary() {
            StringBuilder sb = new StringBuilder();
            sb.append("\n================ DISPATCH EXECUTION REPORT ================\n");
            sb.append(String.format("Successfully Assigned: %d  |  Pending/Unassigned: %d\n",
                    successful.size(), failed.size()));
            sb.append("-----------------------------------------------------------\n");
            for (DispatchRecord r : successful) {
                sb.append(String.format("[SUCCESS] Shipment %-8s (%-8s | %5.1f kg) ==> %-10s (Driver: %s)\n",
                        r.getShipment().getId(), r.getShipment().getShipmentType(),
                        r.getShipment().getWeightKg(), r.getVehicle().getId(), r.getVehicle().getDriverName()));
            }
            for (DispatchRecord r : failed) {
                sb.append(String.format("[FAILED ] Shipment %-8s (%-8s | %5.1f kg) ==> %s\n",
                        r.getShipment().getId(), r.getShipment().getShipmentType(),
                        r.getShipment().getWeightKg(), r.getMessage()));
            }
            sb.append("===========================================================\n");
            return sb.toString();
        }
    }
}
