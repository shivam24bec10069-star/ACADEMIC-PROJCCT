package com.logiflow.service;

import com.logiflow.exception.RouteNotFoundException;
import com.logiflow.model.LocationNode;
import com.logiflow.model.RouteSegment;
import com.logiflow.pattern.FastestRoutingStrategy;
import com.logiflow.pattern.RoutingStrategy;
import com.logiflow.storage.AuditLogger;

import java.util.*;

/**
 * Service managing logistics transit network graph and pathfinding algorithms.
 * Implements Dijkstra's Algorithm with pluggable RoutingStrategy.
 */
public class RoutingService {

    private final Map<String, LocationNode> nodes = new LinkedHashMap<>();
    private final Map<String, List<RouteSegment>> adjacencyList = new HashMap<>();

    public RoutingService() {
        initializeDefaultNetwork();
    }

    public void addNode(LocationNode node) {
        nodes.put(node.getCode(), node);
        adjacencyList.putIfAbsent(node.getCode(), new ArrayList<>());
    }

    public void addSegment(RouteSegment segment, boolean bidirectional) {
        adjacencyList.computeIfAbsent(segment.getSourceCode(), k -> new ArrayList<>()).add(segment);
        if (bidirectional) {
            RouteSegment reverse = new RouteSegment(
                    segment.getDestinationCode(),
                    segment.getSourceCode(),
                    segment.getDistanceKm(),
                    segment.getEstimatedHours(),
                    segment.getTollCost(),
                    segment.getEcoScore()
            );
            adjacencyList.computeIfAbsent(segment.getDestinationCode(), k -> new ArrayList<>()).add(reverse);
        }
    }

    public LocationNode getNode(String code) {
        return nodes.get(code);
    }

    public Collection<LocationNode> getAllNodes() {
        return Collections.unmodifiableCollection(nodes.values());
    }

    public List<RouteSegment> getOutgoingSegments(String nodeCode) {
        return Collections.unmodifiableList(adjacencyList.getOrDefault(nodeCode, Collections.emptyList()));
    }

    /**
     * Finds the optimal path between origin and destination using Dijkstra's algorithm.
     */
    public PathResult findOptimalPath(String originCode, String destinationCode, RoutingStrategy strategy)
            throws RouteNotFoundException {

        if (!nodes.containsKey(originCode) || !nodes.containsKey(destinationCode)) {
            throw new RouteNotFoundException(originCode, destinationCode);
        }

        if (originCode.equalsIgnoreCase(destinationCode)) {
            return new PathResult(Collections.emptyList(), 0, 0, 0, 0, strategy.getName());
        }

        Map<String, Double> distances = new HashMap<>();
        Map<String, RouteSegment> edgeTo = new HashMap<>();
        PriorityQueue<NodeDistance> pq = new PriorityQueue<>(Comparator.comparingDouble(nd -> nd.distance));

        for (String code : nodes.keySet()) {
            distances.put(code, Double.POSITIVE_INFINITY);
        }
        distances.put(originCode, 0.0);
        pq.add(new NodeDistance(originCode, 0.0));

        while (!pq.isEmpty()) {
            NodeDistance current = pq.poll();
            String u = current.nodeCode;

            if (current.distance > distances.get(u)) continue;
            if (u.equals(destinationCode)) break;

            for (RouteSegment segment : adjacencyList.getOrDefault(u, Collections.emptyList())) {
                String v = segment.getDestinationCode();
                double cost = strategy.calculateCost(segment);
                double newDist = distances.get(u) + cost;

                if (newDist < distances.get(v)) {
                    distances.put(v, newDist);
                    edgeTo.put(v, segment);
                    pq.add(new NodeDistance(v, newDist));
                }
            }
        }

        if (distances.get(destinationCode) == Double.POSITIVE_INFINITY) {
            throw new RouteNotFoundException(originCode, destinationCode);
        }

        // Reconstruct path
        LinkedList<RouteSegment> path = new LinkedList<>();
        String curr = destinationCode;
        double totalDistance = 0.0;
        double totalHours = 0.0;
        double totalTolls = 0.0;

        while (edgeTo.containsKey(curr)) {
            RouteSegment seg = edgeTo.get(curr);
            path.addFirst(seg);
            totalDistance += seg.getDistanceKm();
            totalHours += seg.getEstimatedHours();
            totalTolls += seg.getTollCost();
            curr = seg.getSourceCode();
        }

        AuditLogger.getInstance().info("Routing", String.format("Found path %s -> %s via %d hops (%s: %.2f)",
                originCode, destinationCode, path.size(), strategy.getName(), distances.get(destinationCode)));

        return new PathResult(path, totalDistance, totalHours, totalTolls, distances.get(destinationCode), strategy.getName());
    }

    public PathResult findOptimalPath(String originCode, String destinationCode) throws RouteNotFoundException {
        return findOptimalPath(originCode, destinationCode, new FastestRoutingStrategy());
    }

    private void initializeDefaultNetwork() {
        // Major Logistics Hubs
        addNode(new LocationNode("JFK", "New York Distribution Hub", "East", 40.6413, -73.7781));
        addNode(new LocationNode("ORD", "Chicago Central Crossroads", "Midwest", 41.9742, -87.9073));
        addNode(new LocationNode("ATL", "Atlanta Gateway Facility", "Southeast", 33.6407, -84.4277));
        addNode(new LocationNode("DFW", "Dallas-Fort Worth Freight Center", "South", 32.8998, -97.0403));
        addNode(new LocationNode("DEN", "Denver Mountain Depot", "West Central", 39.8561, -104.6737));
        addNode(new LocationNode("LAX", "Los Angeles Pacific Terminal", "West", 33.9416, -118.4085));
        addNode(new LocationNode("SEA", "Seattle Northwest Logistics", "Northwest", 47.4502, -122.3088));
        addNode(new LocationNode("MIA", "Miami International Cargo Hub", "Southeast", 25.7959, -80.2870));

        // Transit Corridors (src, dest, km, hours, tolls, ecoScore 1-10)
        addSegment(new RouteSegment("JFK", "ORD", 1280.0, 14.5, 45.0, 8.5), true);
        addSegment(new RouteSegment("JFK", "ATL", 1370.0, 15.0, 32.0, 7.8), true);
        addSegment(new RouteSegment("ORD", "ATL", 1150.0, 12.0, 18.0, 8.0), true);
        addSegment(new RouteSegment("ORD", "DEN", 1620.0, 16.5, 12.0, 9.0), true);
        addSegment(new RouteSegment("ATL", "MIA", 1070.0, 10.5, 15.0, 8.2), true);
        addSegment(new RouteSegment("ATL", "DFW", 1290.0, 13.5, 20.0, 7.5), true);
        addSegment(new RouteSegment("DFW", "DEN", 1280.0, 13.0, 8.0, 8.8), true);
        addSegment(new RouteSegment("DFW", "LAX", 2300.0, 23.0, 14.0, 7.2), true);
        addSegment(new RouteSegment("DEN", "SEA", 2100.0, 21.5, 10.0, 8.5), true);
        addSegment(new RouteSegment("DEN", "LAX", 1650.0, 17.0, 12.0, 8.0), true);
        addSegment(new RouteSegment("SEA", "LAX", 1830.0, 18.5, 22.0, 9.2), true);
    }

    private static class NodeDistance {
        final String nodeCode;
        final double distance;
        NodeDistance(String nodeCode, double distance) {
            this.nodeCode = nodeCode;
            this.distance = distance;
        }
    }

    public static class PathResult {
        private final List<RouteSegment> segments;
        private final double totalDistanceKm;
        private final double totalHours;
        private final double totalTolls;
        private final double optimizationMetric;
        private final String strategyName;

        public PathResult(List<RouteSegment> segments, double totalDistanceKm, double totalHours,
                          double totalTolls, double optimizationMetric, String strategyName) {
            this.segments = segments;
            this.totalDistanceKm = totalDistanceKm;
            this.totalHours = totalHours;
            this.totalTolls = totalTolls;
            this.optimizationMetric = optimizationMetric;
            this.strategyName = strategyName;
        }

        public List<RouteSegment> getSegments() { return segments; }
        public double getTotalDistanceKm() { return totalDistanceKm; }
        public double getTotalHours() { return totalHours; }
        public double getTotalTolls() { return totalTolls; }
        public double getOptimizationMetric() { return optimizationMetric; }
        public String getStrategyName() { return strategyName; }

        public String formatPathSummary() {
            if (segments.isEmpty()) return "Origin and destination are identical (0 km).";
            StringBuilder sb = new StringBuilder();
            sb.append(segments.get(0).getSourceCode());
            for (RouteSegment seg : segments) {
                sb.append(" -> ").append(seg.getDestinationCode());
            }
            sb.append(String.format(" | Distance: %.1f km | Est. Time: %.1f hrs | Tolls: $%.2f",
                    totalDistanceKm, totalHours, totalTolls));
            return sb.toString();
        }
    }
}
