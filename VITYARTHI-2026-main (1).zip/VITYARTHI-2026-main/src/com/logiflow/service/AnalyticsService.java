package com.logiflow.service;

import com.logiflow.exception.RouteNotFoundException;
import com.logiflow.model.*;
import com.logiflow.pattern.FastestRoutingStrategy;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Enterprise analytics engine leveraging Java Stream API and functional paradigms
 * for operational KPIs, financial reporting, and fleet utilization metrics.
 */
public class AnalyticsService {

    private final ShipmentService shipmentService;
    private final FleetService fleetService;
    private final RoutingService routingService;

    public AnalyticsService(ShipmentService shipmentService, FleetService fleetService, RoutingService routingService) {
        this.shipmentService = shipmentService;
        this.fleetService = fleetService;
        this.routingService = routingService;
    }

    /**
     * Calculates the estimated distance between shipment origin and destination.
     */
    public double getEstimatedDistance(Shipment s) {
        try {
            return routingService.findOptimalPath(s.getOriginCode(), s.getDestinationCode(), new FastestRoutingStrategy())
                    .getTotalDistanceKm();
        } catch (RouteNotFoundException e) {
            return 850.0; // Fallback estimate
        }
    }

    /**
     * Computes total revenue generated across all registered shipments using Streams.
     */
    public double calculateTotalRevenue() {
        return shipmentService.getAllShipments().stream()
                .mapToDouble(s -> s.calculateCost(getEstimatedDistance(s)))
                .sum();
    }

    /**
     * Groups revenue by shipment classification (STANDARD, EXPRESS, FRAGILE).
     */
    public Map<String, Double> getRevenueByShipmentType() {
        return shipmentService.getAllShipments().stream()
                .collect(Collectors.groupingBy(
                        Shipment::getShipmentType,
                        Collectors.summingDouble(s -> Math.round(s.calculateCost(getEstimatedDistance(s)) * 100.0) / 100.0)
                ));
    }

    /**
     * Counts shipments grouped by their current lifecycle status.
     */
    public Map<ShipmentStatus, Long> getStatusDistribution() {
        return shipmentService.getAllShipments().stream()
                .collect(Collectors.groupingBy(Shipment::getStatus, Collectors.counting()));
    }

    /**
     * Computes statistical summary (count, sum, min, average, max) for shipment weights.
     */
    public DoubleSummaryStatistics getWeightStatistics() {
        return shipmentService.getAllShipments().stream()
                .collect(Collectors.summarizingDouble(Shipment::getWeightKg));
    }

    /**
     * Computes statistical summary for declared values.
     */
    public DoubleSummaryStatistics getDeclaredValueStatistics() {
        return shipmentService.getAllShipments().stream()
                .collect(Collectors.summarizingDouble(Shipment::getDeclaredValue));
    }

    /**
     * Calculates average payload capacity utilization across all fleet vehicles.
     */
    public double getAverageFleetUtilization() {
        List<Vehicle> vehicles = fleetService.getAllVehicles();
        if (vehicles.isEmpty()) return 0.0;
        return vehicles.stream()
                .mapToDouble(Vehicle::getUtilizationPercentage)
                .average()
                .orElse(0.0);
    }

    /**
     * Estimates total carbon footprint (kg CO2) based on total kilometers logged by fleet.
     */
    public double calculateTotalCarbonFootprintKg() {
        return fleetService.getAllVehicles().stream()
                .mapToDouble(v -> v.getTotalKmDriven() * v.getType().getCarbonPerKmKg())
                .sum();
    }

    /**
     * Generates a comprehensive formatted analytical executive report.
     */
    public String generateAnalyticalReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("=================================================================================\n");
        sb.append("                     LOGIFLOW PRO - OPERATIONAL ANALYTICS REPORT                  \n");
        sb.append("=================================================================================\n");

        double totalRevenue = calculateTotalRevenue();
        sb.append(String.format(" Total Estimated Revenue     : $%,12.2f\n", totalRevenue));

        Map<String, Double> revByType = getRevenueByShipmentType();
        sb.append(" Revenue Breakdown by Type   :\n");
        revByType.forEach((type, rev) ->
                sb.append(String.format("   * %-12s : $%,10.2f (%5.1f%%)\n",
                        type, rev, totalRevenue > 0 ? (rev / totalRevenue) * 100.0 : 0.0)));

        sb.append("\n Shipment Status Breakdown  :\n");
        Map<ShipmentStatus, Long> statusMap = getStatusDistribution();
        statusMap.forEach((status, count) ->
                sb.append(String.format("   * %-25s : %d shipments\n", status.getDisplayName(), count)));

        DoubleSummaryStatistics weightStats = getWeightStatistics();
        sb.append("\n Cargo Weight Analytics (kg):\n");
        sb.append(String.format("   * Total Weight Dispatched : %,10.1f kg\n", weightStats.getSum()));
        sb.append(String.format("   * Average Parcel Weight   : %,10.1f kg\n", weightStats.getAverage()));
        sb.append(String.format("   * Heaviest Single Parcel  : %,10.1f kg\n", weightStats.getMax()));

        DoubleSummaryStatistics valStats = getDeclaredValueStatistics();
        sb.append("\n Asset Valuation Analytics  :\n");
        sb.append(String.format("   * Total Declared Value    : $%,12.2f\n", valStats.getSum()));
        sb.append(String.format("   * Average Consignment Val : $%,12.2f\n", valStats.getAverage()));

        sb.append("\n Fleet Operations & Green KPIs:\n");
        sb.append(String.format("   * Total Fleet Units       : %d vehicles\n", fleetService.getAllVehicles().size()));
        sb.append(String.format("   * Ready / Dispatched      : %d / %d\n",
                fleetService.getAvailableVehicles().size(),
                fleetService.getAllVehicles().size() - fleetService.getAvailableVehicles().size()));
        sb.append(String.format("   * Mean Fleet Utilization  : %.1f%%\n", getAverageFleetUtilization()));
        sb.append(String.format("   * Carbon Footprint Logged : %.2f kg CO2\n", calculateTotalCarbonFootprintKg()));

        sb.append("=================================================================================\n");
        return sb.toString();
    }
}
